# 2. Provide a program to read the CSV file.
# • CSV file has three columns, the first column names, the second column is birthdate(YYYYMM-DD) the third column is salary.
# • Read the file and display the data and age in the terminal.
# • The file path, delimiter, and quote char are the input by the user.
# • The program has to work from the terminal. The input and output have been taken/displayed
# on the terminal.


import csv
from datetime import date, datetime
import os


currentdate = date.today()
age = 0
with open('two.csv', mode='r') as file:
    two = csv.reader(file)
    for lines in two:
        if lines[1] != "Birthdate":
            
            fdate = lines[1].partition('-')
            year = int(fdate[0])
            fdate = fdate[2].partition('-')
            month = int(fdate[0])
            day = int(fdate[2])

            bdate = datetime(year, month, day)
            # print(year, month, day)
            if(currentdate.month > bdate.month):
                age = currentdate.year - bdate.year
            elif(currentdate.month < bdate.month):
                age = (currentdate.year - bdate.year) - 1
            else:
                if(currentdate.day >= bdate.day):
                    age = currentdate.year - bdate.year
                else:
                    age = (currentdate.year - bdate.year) - 1
            
        else:
            age = str("age")
        lines.append(age)    
        print(lines)

print("\n\n")
print('File name : ', os.path.basename(__file__))
print('Directory Name:	 ', os.path.dirname(__file__))
