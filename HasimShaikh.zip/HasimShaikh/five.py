# 5. Provide a program to create tables (Employee, Department,
# Project) in database Sqlite and insert the data.
# • Make sure to add basic field, with employee to department and project relation.
# • Make sure maintain M2M relation between employee and project. 

import sqlite3

conn = sqlite3.connect('Five.db')

# #  Employee table created
# conn.execute('''CREATE TABLE EMPLOYEE
#             (ID INT PRIMARY KEY NOT NULL,
#             ENAME TEXT NOT NULL,
#             PHONE INT NOT NULL,
#             SALARY  REAL);''')

# #  Employee Data inserted.
# conn.execute("INSERT INTO EMPLOYEE (ID,ENAME,PHONE,SALARY) \
#       VALUES (1, 'Tony', '1254891245',  22000.00 )")

# conn.execute("INSERT INTO EMPLOYEE (ID,ENAME,PHONE,SALARY) \
#       VALUES (2, 'Natasha', '21451009125', 15000.00 )")

# conn.execute("INSERT INTO EMPLOYEE (ID,ENAME,PHONE,SALARY) \
#       VALUES (3, 'Steave', '2348763109',  20000.00 )")

# conn.execute("INSERT INTO EMPLOYEE (ID,ENAME,PHONE,SALARY) \
#       VALUES (4, 'Vision', '9945103625',  15000.00 )")

# conn.commit()
# print ("Recorded.")


# #  Department table created
# # conn.execute('''DROP TABLE DEPARTMENT''') # For delete table.

# conn.execute('''CREATE TABLE DEPARTMENT
#             (ID INT PRIMARY KEY NOT NULL,
#             DEPT TEXT NOT NULL,
#             EMP_ID INT NOT NULL,
#             FOREIGN KEY(EMP_ID) REFERENCES EMPLOYEE(ID));''')

# # data inserted.
# conn.execute("INSERT INTO DEPARTMENT(ID,DEPT,EMP_ID) \
# VALUES (1, 'Sales', 4)")
# conn.execute("INSERT INTO DEPARTMENT(ID,DEPT,EMP_ID) \
# VALUES (2, 'IT Head', 1)")
# conn.execute("INSERT INTO DEPARTMENT(ID,DEPT,EMP_ID) \
# VALUES (3, 'Defense Head',3)")
# conn.execute("INSERT INTO DEPARTMENT(ID,DEPT,EMP_ID) \
# VALUES (4, 'Finance', 2)")

# conn.commit()
# print ("Recorded.")



# # Project

# conn.execute('''CREATE TABLE PROJECT
#             (ID INT PRIMARY KEY NOT NULL,
#             PRO TEXT NOT NULL,
#             EMP_ID INT NOT NULL,
#             DEPT_ID INT NOT NULL,
#             FOREIGN KEY(EMP_ID) REFERENCES EMPLOYEE(ID),
#             FOREIGN KEY(DEPT_ID) REFERENCES DEPARTMENT(ID));''')

# data inserted.
# conn.execute("INSERT INTO PROJECT(ID, PRO, EMP_ID, DEPT_ID) \
# VALUES (1, 'Automation', 1, 2)")
# conn.execute("INSERT INTO PROJECT(ID, PRO, EMP_ID, DEPT_ID) \
# VALUES (2, 'GST File', 2, 2)")
# conn.execute("INSERT INTO PROJECT(ID, PRO, EMP_ID, DEPT_ID) \
# VALUES (3, 'Cyber Security', 3, 3)")
# conn.execute("INSERT INTO PROJECT(ID, PRO, EMP_ID, DEPT_ID) \
# VALUES (4, 'Profit CAL', 4, 4)")

# conn.commit()
# print ("Recorded.")


# # printting data from employee
# data = conn.execute('''SELECT * FROM EMPLOYEE;''')
# for row in data:
#     print("\nID : " + str(row[0]))
#     print("NAME : " + str(row[1]))
#     print("PHONE : " + str(row[2]))
#     print("SALARY : " + str(row[3]))
   
# conn.commit()

# # printting data from department
# data = conn.execute('''SELECT * FROM DEPARTMENT;''')
# for row in data:
#     print("\nID : " + str(row[0]))
#     print("DEPTARTMENT : " + str(row[1]))
#     print("EMP_ID : " + str(row[2]))
   
# conn.commit()


# # printting data from project
# data = conn.execute('''SELECT * FROM PROJECT;''')
# for row in data:
#     print("\nID : " + str(row[0]))
#     print("PROJECT : " + str(row[1]))
#     print("EMP_ID : " + str(row[2]))
#     print("DEPT_ID : " + str(row[3]))
    
# conn.commit()

# CROSS JOIN in sqlite3
# data = conn.execute('''SELECT EMP_ID, ENAME, DEPT FROM EMPLOYEE CROSS JOIN DEPARTMENT;''')
# for row in data:
#     print("\nID : " + str(row[0]))
#     print("ENAME : " + str(row[1]))
#     print("DEPT : " + str(row[2]))
    
conn.close()
    