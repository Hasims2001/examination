# 3. Provide a program to calculate the time and distance based on
# below problem.
# • We have a 100-meter rod.
# • At both ends, 1-1 cockroach is place.
# • The left cockroach moves at 1 meter per second forward, and every 10 seconds moves 2
# meters backward.
# • The right cockroach moves at 2 meters per second forward, and every 5 seconds moves 1
# meter backward.
# • When both cockroaches meet, we have to calculate the time and distance. Calculate the total
# time to complete the 100 meter rod.


dist = 100

# When both cockroaches meet?

# let left and right meet x second after start wallking.
#  0.8x +  1.8x = 100 meter 
# or  
# 100/2.6 = 38.46
# so, 0.8x38.46  + 1.8x38.46 = 100
#     30.768     +   69.228  = 100

meet = dist / (0.8+1.8)
l_meet = 0.8*38.46
r_meet = 1.8*38.46
print("speedXtime + speedXtime = 100")
print("{:.2f}  +  {:.2f}  =  {} ".format(l_meet, r_meet, dist))

print ("Both Cockroaches meet on {:.2f} meter".format(meet) )


# for x in range(1, 101):
#     if x*1.25 == x*0.55:
#         print("Both Cockroaches meet : " + str(x)) 
    




# LEFT COCK walk 10 second, distance will cover 10 meter but every 10 second 2 meter move back, so per 10 second COCK move 8 meter.
# If LEFT COCK cover  : 8 meter in 10 seconds (4 meter in 5 seconds)
#  then               : 100 meter in how?  
#  then               : 100*10/8
# speed = 100/125  = 0.80 (m/s)

l_time = float(dist*10/8)  #125 Seconds
print("\nLeft cockroach will complete 100 meter road in " + str(l_time) + " seconds.")


# RIGHT COCK walk 5 second, distance will cover 10 meter but every 5 second 1 meter move back, so per 5 second COCK move 9 meter.
# If RIGHT COCK cover  : 9 meter in 5 seconds
# then                 : 100 meter in how?
# then                 : 100*5/9
# speed = 100/55.55  = 1.80 (m/s)

r_time = float(dist*5/9) #55.55 Seconds     
print("Right cockroach will complete 100 meter road in " + str(r_time) + " seconds.")


